import React from 'react';
// import { BsCheckSquare } from 'react-icons/bs';

// const icons = {
//     BsCheckSquare
// };

const RecentOrders = () => {
    return (
        <>
            <section>
                <div className="Delievered-orders">
                    <div class="success-icon">Icon</div>
                    <div>
                        <h1>Delievered Orders</h1>
                        <span>3.5%</span>
                        <span style={{ display: 'block' }}>increased</span>
                    </div>
                    <div class="order-total">1768</div>
                </div>
                <div className="Cancelled-orders">
                    <h1>Cancelled orders</h1>
                    <span>1.2%</span>
                    <span style={{ display: 'block' }}>increased</span>
                </div>
            </section>
        </>
    );
};
export default RecentOrders;
