// assets
import { LoginOutlined, ProfileOutlined, ThunderboltOutlined } from '@ant-design/icons';

// icons
const icons = {
    LoginOutlined,
    ProfileOutlined,
    ThunderboltOutlined
};

// ==============================|| MENU ITEMS - EXTRA PAGES ||============================== //

const pages = {
    id: 'authentication',
    title: 'UI KIT',
    type: 'group',
    children: [
        {
            id: 'login1',
            title: 'Apps',
            type: 'item',
            url: '/login',
            icon: icons.LoginOutlined,
            target: true
        },
        {
            id: 'register1',
            title: 'Bootstrap',
            type: 'item',
            url: '/register',
            icon: icons.ProfileOutlined,
            target: true
        },
        {
            id: 'landingpage',
            title: 'Landing Page',
            type: 'item',
            url: '/landingpage',
            icon: icons.ThunderboltOutlined
        }
    ]
};

export default pages;
