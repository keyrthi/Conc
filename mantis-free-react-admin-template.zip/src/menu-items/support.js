// assets
import { UsergroupDeleteOutlined, QuestionOutlined } from '@ant-design/icons';

// icons
const icons = {
    UsergroupDeleteOutlined,
    QuestionOutlined
};

// ==============================|| MENU ITEMS - SAMPLE PAGE & DOCUMENTATION ||============================== //

const support = {
    id: 'support',
    title: 'MISC PAGES',
    type: 'group',
    children: [
        {
            id: 'sample-page',
            title: 'Authentication',
            type: 'item',
            url: '/sample-page',
            icon: icons.UsergroupDeleteOutlined
        },
        {
            id: 'documentation',
            title: 'Submenu Items',
            type: 'item',
            url: 'https://codedthemes.gitbook.io/mantis-react/',
            icon: icons.QuestionOutlined,
            external: true,
            target: true
        }
    ]
};

export default support;
