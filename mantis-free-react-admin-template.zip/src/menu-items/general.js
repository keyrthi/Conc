// assets
import { HeatMapOutlined, BarChartOutlined, ThunderboltOutlined } from '@ant-design/icons';

// icons
const icons = {
    HeatMapOutlined,
    BarChartOutlined,
    ThunderboltOutlined
};

// ==============================|| MENU ITEMS - EXTRA PAGES ||============================== //

const general = {
    id: 'authentication',
    title: 'GENERAL',
    type: 'group',
    children: [
        {
            id: 'login1',
            title: 'Maps',
            type: 'item',
            url: '/login',
            icon: icons.HeatMapOutlined,
            target: true
        },
        {
            id: 'register1',
            title: 'Charts',
            type: 'item',
            url: '/register',
            icon: icons.BarChartOutlined,
            target: true
        },
        {
            id: 'landingpage',
            title: 'Icons',
            type: 'item',
            url: '/landingpage',
            icon: icons.ThunderboltOutlined
        }
    ]
};

export default general;
